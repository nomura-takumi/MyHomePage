/*
	�^�C�g��		Othello

	�쐬�ҁ@		�쑺
	�쐬��			2023/06/03
*/

#include <iostream>
#include <stdlib.h>
#include "main.h"
#include "my_winsock.h"

#include "Player.h"


int main(void) {
	std::cout << "�\�P�b�g�ʐM�����܂����H" << std::endl;
	std::cout << "y / n : ";
	char ans;
	std::cin >> ans;
	rewind(stdin);
	if (ans == 'y') {
		system("cls");
		//�ʐM���J�n
		p_winsock = new MyWinSock();
	}

	if (p_winsock != nullptr) {
		//�G���[�R�[�h��0�Ȃ�ΐڑ�����
		if (p_winsock->GetErrorCode() == 0) {
			Init();
		}
		else {
			p_winsock->PrintErrorCode(p_winsock->GetErrorCode());
			getchar();
			delete p_winsock;
			p_winsock = nullptr;
			return 0;
		}
	}
	else {
		Init();
	}

	//���s�����܂��Ă��Ȃ��ԁA���[�v
	while (!m_finish) {
		Update();
		Draw();

		if (p_winsock != nullptr) {
			//�G���[�R�[�h�̕\��
			if (p_winsock->GetErrorCode() != 0) {
				p_winsock->PrintErrorCode(p_winsock->GetErrorCode());
				getchar();
				break;
			}
		}
	}
	
	Uninit();
}


void Init()
{
	system("cls");
	p_board = new Board();
	p_player_server = new Player();
	p_player_client = new Player();

	if (p_winsock != nullptr) {
		p_winsock->SetPlayerInstance(p_player_client);
	}
	//�Ֆʂ̃C���X�^���X�����ꂼ��ɋ�����
	p_player_server->SetBoardInstance(p_board);
	p_player_client->SetBoardInstance(p_board);

	//�Ֆʂ̏����z�u
	SetPreset(Preset::DEFAULT);
	//SetPreset(Preset::SERVER_WIN);
	//SetPreset(Preset::SERVER_DEFEAT);
	//SetPreset(Preset::SERVER_MULTI_CLOSE);
	//SetPreset(Preset::CLIENT_MULTI_CLOSE);
	//SetPreset(Preset::SERVER_COMPLETE);
	//SetPreset(Preset::CLIENT_COMPLETE);
	//SetPreset(Preset::SERVER_PASS);
	//SetPreset(Preset::CLIENT_PASS);
	//SetPreset(Preset::OUTRANGE);
	p_board->Draw();
}

void Uninit()
{
	delete p_player_client;
	p_player_client = nullptr;
	
	delete p_player_server;
	p_player_server = nullptr;

	delete p_board;
	p_board = nullptr;

	if (p_winsock != nullptr) {
		delete p_winsock;
		p_winsock = nullptr;
	}
}

void Update()
{
	//�p�X�Ǝ�l�܂�̔���
	if (p_board->CheckPassOrDeadLock(m_turn)) {
		m_pass_times++;

		//��l�܂�ɂȂ���
		if (m_pass_times >= 2) {
			for (auto map : p_board->CheckFinish(true)) {
				if (map.first) {
					Finish(map.second);
					return;
				}
			}
		}

		m_turn = static_cast<Board::BoardState>(static_cast<int>(m_turn) * -1);
		std::cout << "�@�p�X�ł�" << std::endl << std::endl;
		rewind(stdin);
		getchar();
		return;
	}

	switch (m_turn) {
	case Board::BoardState::SERVER:	
		m_pass_times = 0;
		std::cout << "�@�T�[�o�[��(��)�̔Ԃł� (Enter�L�[�Ō���)" << std::endl << std::endl;

		p_player_server->Input(Board::BoardState::SERVER);
		break;
	case Board::BoardState::CLIENT:
		m_pass_times = 0;
		std::cout << "�@�N���C�A���g��(��)�̔Ԃł� (Enter�L�[�Ō���)" << std::endl << std::endl;

		//�ڑ���ԂƔ�ڑ���ԂŐ؂�ւ���
		if (p_winsock != nullptr) {
			p_winsock->Update();
		}
		else {
			p_player_client->Input(Board::BoardState::CLIENT);
		}
		break;
	}

	//���Ԃ̔��]
	m_turn = static_cast<Board::BoardState>(static_cast<int>(m_turn) * -1);
}

void Draw()
{
	p_board->Draw();
	
	for (auto map : p_board->CheckFinish()) {
		if (map.first) {
			Finish(map.second);
		}
	}
}

inline void SetPreset(Preset preset) {
	switch (preset) {
	case DEFAULT:
		p_board->SetBoard(4, 4, Board::BoardState::SERVER);
		p_board->SetBoard(5, 5, Board::BoardState::SERVER);
		p_board->SetBoard(4, 5, Board::BoardState::CLIENT);
		p_board->SetBoard(5, 4, Board::BoardState::CLIENT);
		break;
	case SERVER_WIN:
		//���̎�ŃT�[�o�[��������
		for (int x = 1; x < 9; x++) {
			for (int y = 1; y < 9; y++) {
				p_board->SetBoard(x, y, Board::BoardState::CLIENT);
			}
		}
		
		p_board->SetBoard(1, 2, Board::BoardState::SERVER);
		p_board->SetBoard(1, 3, Board::BoardState::SERVER);
		p_board->SetBoard(1, 4, Board::BoardState::SERVER);
		p_board->SetBoard(1, 5, Board::BoardState::SERVER);
		p_board->SetBoard(1, 6, Board::BoardState::SERVER);
		p_board->SetBoard(1, 7, Board::BoardState::SERVER);
		p_board->SetBoard(1, 8, Board::BoardState::SERVER);
		p_board->SetBoard(2, 2, Board::BoardState::SERVER);
		p_board->SetBoard(2, 7, Board::BoardState::SERVER);
		p_board->SetBoard(3, 2, Board::BoardState::SERVER);
		p_board->SetBoard(3, 4, Board::BoardState::SERVER);
		p_board->SetBoard(3, 6, Board::BoardState::SERVER);
		p_board->SetBoard(3, 7, Board::BoardState::SERVER);
		p_board->SetBoard(4, 2, Board::BoardState::SERVER);
		p_board->SetBoard(4, 3, Board::BoardState::SERVER);
		p_board->SetBoard(4, 4, Board::BoardState::SERVER);
		p_board->SetBoard(4, 5, Board::BoardState::SERVER);
		p_board->SetBoard(4, 6, Board::BoardState::SERVER);
		p_board->SetBoard(5, 2, Board::BoardState::SERVER);
		p_board->SetBoard(5, 3, Board::BoardState::SERVER);
		p_board->SetBoard(5, 4, Board::BoardState::SERVER);
		p_board->SetBoard(5, 5, Board::BoardState::SERVER);
		p_board->SetBoard(6, 2, Board::BoardState::SERVER);
		p_board->SetBoard(6, 3, Board::BoardState::SERVER);
		p_board->SetBoard(6, 4, Board::BoardState::SERVER);
		p_board->SetBoard(6, 5, Board::BoardState::SERVER);
		p_board->SetBoard(7, 2, Board::BoardState::SERVER);
		p_board->SetBoard(7, 3, Board::BoardState::SERVER);
		p_board->SetBoard(7, 5, Board::BoardState::SERVER);
		p_board->SetBoard(7, 6, Board::BoardState::SERVER);
		p_board->SetBoard(8, 1, Board::BoardState::SERVER);
		p_board->SetBoard(8, 2, Board::BoardState::SERVER);
		p_board->SetBoard(8, 3, Board::BoardState::SERVER);
		p_board->SetBoard(8, 4, Board::BoardState::SERVER);
		p_board->SetBoard(8, 5, Board::BoardState::SERVER);
		p_board->SetBoard(8, 6, Board::BoardState::SERVER);
		p_board->SetBoard(8, 7, Board::BoardState::SERVER);

		p_board->SetBoard(7, 7, Board::BoardState::NONE);
		m_turn = Board::BoardState::CLIENT;
		break;
	case SERVER_DEFEAT:
		//���̎�ŃN���C�A���g��������
		for (int x = 1; x < 9; x++) {
			for (int y = 1; y < 9; y++) {
				p_board->SetBoard(x, y, Board::BoardState::CLIENT);
			}
		}

		p_board->SetBoard(1, 2, Board::BoardState::SERVER);
		p_board->SetBoard(1, 3, Board::BoardState::SERVER);
		p_board->SetBoard(1, 4, Board::BoardState::SERVER);
		p_board->SetBoard(1, 5, Board::BoardState::SERVER);
		p_board->SetBoard(1, 6, Board::BoardState::SERVER);
		p_board->SetBoard(1, 7, Board::BoardState::SERVER);
		p_board->SetBoard(1, 8, Board::BoardState::SERVER);
		p_board->SetBoard(2, 2, Board::BoardState::SERVER);
		p_board->SetBoard(2, 7, Board::BoardState::SERVER);
		p_board->SetBoard(3, 4, Board::BoardState::SERVER);
		p_board->SetBoard(3, 6, Board::BoardState::SERVER);
		p_board->SetBoard(3, 7, Board::BoardState::SERVER);
		p_board->SetBoard(4, 3, Board::BoardState::SERVER);
		p_board->SetBoard(4, 4, Board::BoardState::SERVER);
		p_board->SetBoard(4, 5, Board::BoardState::SERVER);
		p_board->SetBoard(4, 6, Board::BoardState::SERVER);
		p_board->SetBoard(4, 7, Board::BoardState::SERVER);
		p_board->SetBoard(5, 3, Board::BoardState::SERVER);
		p_board->SetBoard(5, 4, Board::BoardState::SERVER);
		p_board->SetBoard(5, 5, Board::BoardState::SERVER);
		p_board->SetBoard(5, 7, Board::BoardState::SERVER);
		p_board->SetBoard(6, 3, Board::BoardState::SERVER);
		p_board->SetBoard(6, 4, Board::BoardState::SERVER);
		p_board->SetBoard(6, 5, Board::BoardState::SERVER);
		p_board->SetBoard(6, 6, Board::BoardState::SERVER);
		p_board->SetBoard(6, 7, Board::BoardState::SERVER);
		p_board->SetBoard(7, 3, Board::BoardState::SERVER);
		p_board->SetBoard(7, 5, Board::BoardState::SERVER);
		p_board->SetBoard(7, 6, Board::BoardState::SERVER);
		p_board->SetBoard(7, 7, Board::BoardState::SERVER);
		p_board->SetBoard(8, 1, Board::BoardState::SERVER);
		p_board->SetBoard(8, 7, Board::BoardState::SERVER);

		p_board->SetBoard(8, 2, Board::BoardState::NONE);
		m_turn = Board::BoardState::CLIENT;
		break;
	case SERVER_MULTI_CLOSE:
		//���̎�ŃT�[�o�[�����΂𕡐����Ԃ����
		p_board->SetBoard(4, 4, Board::BoardState::CLIENT);
		p_board->SetBoard(5, 3, Board::BoardState::CLIENT);
		p_board->SetBoard(5, 4, Board::BoardState::CLIENT);
		p_board->SetBoard(5, 5, Board::BoardState::CLIENT);
		p_board->SetBoard(4, 5, Board::BoardState::SERVER);
		break;
	case CLIENT_MULTI_CLOSE:
		//���̎�ŃN���C�A���g�����΂𕡐����Ԃ����
		p_board->SetBoard(4, 4, Board::BoardState::SERVER);
		p_board->SetBoard(5, 3, Board::BoardState::SERVER);
		p_board->SetBoard(5, 4, Board::BoardState::SERVER);
		p_board->SetBoard(5, 5, Board::BoardState::SERVER);
		p_board->SetBoard(4, 5, Board::BoardState::CLIENT);
		m_turn = Board::BoardState::CLIENT;
		break;
	case SERVER_COMPLETE:
		//���̎�ŃT�[�o�[�������������
		p_board->SetBoard(5, 3, Board::BoardState::SERVER);
		p_board->SetBoard(5, 4, Board::BoardState::SERVER);
		p_board->SetBoard(5, 6, Board::BoardState::SERVER);
		p_board->SetBoard(5, 7, Board::BoardState::SERVER);
		p_board->SetBoard(6, 4, Board::BoardState::SERVER);
		p_board->SetBoard(6, 6, Board::BoardState::SERVER);
		p_board->SetBoard(7, 5, Board::BoardState::SERVER);
		p_board->SetBoard(4, 4, Board::BoardState::CLIENT);
		p_board->SetBoard(4, 5, Board::BoardState::CLIENT);
		p_board->SetBoard(4, 6, Board::BoardState::CLIENT);
		p_board->SetBoard(5, 5, Board::BoardState::CLIENT);
		p_board->SetBoard(6, 5, Board::BoardState::CLIENT);
		break;
	case CLIENT_COMPLETE:
		//���̎�ŃN���C�A���g�������������
		p_board->SetBoard(5, 3, Board::BoardState::CLIENT);
		p_board->SetBoard(5, 4, Board::BoardState::CLIENT);
		p_board->SetBoard(5, 6, Board::BoardState::CLIENT);
		p_board->SetBoard(5, 7, Board::BoardState::CLIENT);
		p_board->SetBoard(6, 4, Board::BoardState::CLIENT);
		p_board->SetBoard(6, 6, Board::BoardState::CLIENT);
		p_board->SetBoard(7, 5, Board::BoardState::CLIENT);
		p_board->SetBoard(4, 4, Board::BoardState::SERVER);
		p_board->SetBoard(4, 5, Board::BoardState::SERVER);
		p_board->SetBoard(4, 6, Board::BoardState::SERVER);
		p_board->SetBoard(5, 5, Board::BoardState::SERVER);
		p_board->SetBoard(6, 5, Board::BoardState::SERVER);
		m_turn = Board::BoardState::CLIENT;
		break;
	case SERVER_PASS:
		//���̎�ŃT�[�o�[�����p�X�������
		p_board->SetBoard(3, 4, Board::BoardState::SERVER);
		p_board->SetBoard(4, 4, Board::BoardState::SERVER);
		p_board->SetBoard(4, 5, Board::BoardState::SERVER);
		p_board->SetBoard(5, 4, Board::BoardState::SERVER);
		p_board->SetBoard(5, 5, Board::BoardState::SERVER);
		p_board->SetBoard(5, 6, Board::BoardState::SERVER);
		p_board->SetBoard(5, 8, Board::BoardState::SERVER);
		p_board->SetBoard(6, 6, Board::BoardState::SERVER);
		p_board->SetBoard(7, 6, Board::BoardState::SERVER);
		p_board->SetBoard(4, 8, Board::BoardState::CLIENT);
		p_board->SetBoard(5, 7, Board::BoardState::CLIENT);
		m_turn = Board::BoardState::CLIENT;
		break;
	case CLIENT_PASS:
		//���̎�ŃN���C�A���g�����p�X�������
		p_board->SetBoard(3, 4, Board::BoardState::CLIENT);
		p_board->SetBoard(4, 4, Board::BoardState::CLIENT);
		p_board->SetBoard(4, 5, Board::BoardState::CLIENT);
		p_board->SetBoard(5, 4, Board::BoardState::CLIENT);
		p_board->SetBoard(5, 5, Board::BoardState::CLIENT);
		p_board->SetBoard(5, 6, Board::BoardState::CLIENT);
		p_board->SetBoard(5, 8, Board::BoardState::CLIENT);
		p_board->SetBoard(6, 6, Board::BoardState::CLIENT);
		p_board->SetBoard(7, 6, Board::BoardState::CLIENT);
		p_board->SetBoard(4, 8, Board::BoardState::SERVER);
		p_board->SetBoard(5, 7, Board::BoardState::SERVER);
		break;
	case OUTRANGE:
		//���̎�ň��������ɂȂ��
		for (int x = 1; x < 9; x++) {
			for (int y = 1; y < 9; y++) {
				p_board->SetBoard(x, y, Board::BoardState::CLIENT);
			}
		}

		p_board->SetBoard(1, 1, Board::BoardState::SERVER);
		p_board->SetBoard(1, 2, Board::BoardState::SERVER);
		p_board->SetBoard(1, 3, Board::BoardState::SERVER);
		p_board->SetBoard(1, 4, Board::BoardState::SERVER);
		p_board->SetBoard(1, 5, Board::BoardState::SERVER);
		p_board->SetBoard(1, 6, Board::BoardState::SERVER);
		p_board->SetBoard(1, 8, Board::BoardState::SERVER);
		p_board->SetBoard(2, 1, Board::BoardState::SERVER);
		p_board->SetBoard(2, 5, Board::BoardState::SERVER);
		p_board->SetBoard(2, 6, Board::BoardState::SERVER);
		p_board->SetBoard(2, 7, Board::BoardState::SERVER);
		p_board->SetBoard(2, 8, Board::BoardState::SERVER);
		p_board->SetBoard(3, 1, Board::BoardState::SERVER);
		p_board->SetBoard(3, 4, Board::BoardState::SERVER);
		p_board->SetBoard(3, 6, Board::BoardState::SERVER);
		p_board->SetBoard(3, 8, Board::BoardState::SERVER);
		p_board->SetBoard(4, 1, Board::BoardState::SERVER);
		p_board->SetBoard(4, 3, Board::BoardState::SERVER);
		p_board->SetBoard(4, 4, Board::BoardState::SERVER);
		p_board->SetBoard(4, 5, Board::BoardState::SERVER);
		p_board->SetBoard(4, 6, Board::BoardState::SERVER);
		p_board->SetBoard(4, 7, Board::BoardState::SERVER);
		p_board->SetBoard(5, 1, Board::BoardState::SERVER);
		p_board->SetBoard(5, 4, Board::BoardState::SERVER);
		p_board->SetBoard(5, 7, Board::BoardState::SERVER);
		p_board->SetBoard(5, 8, Board::BoardState::SERVER);
		p_board->SetBoard(6, 1, Board::BoardState::SERVER);
		p_board->SetBoard(6, 3, Board::BoardState::SERVER);
		p_board->SetBoard(6, 7, Board::BoardState::SERVER);
		p_board->SetBoard(7, 1, Board::BoardState::SERVER);
		p_board->SetBoard(7, 4, Board::BoardState::SERVER);
		p_board->SetBoard(7, 6, Board::BoardState::SERVER);
		p_board->SetBoard(7, 7, Board::BoardState::SERVER);
		p_board->SetBoard(8, 1, Board::BoardState::SERVER);

		p_board->SetBoard(1, 7, Board::BoardState::NONE);
		m_turn = Board::BoardState::CLIENT;
		break;
	}
}

void Finish(Board::BoardState state)
{
	switch (state) {
	case Board::BoardState::SERVER:
		std::cout << "�T�[�o�[���̏����ł�";
		break;
	case Board::BoardState::CLIENT:
		std::cout << "�N���C�A���g���̏����ł�";
		break;
	case Board::BoardState::OUT_RANGE:
		std::cout << "���������ł�";
		break;
	}
	rewind(stdin);
	getchar();
	m_finish = true;
}
