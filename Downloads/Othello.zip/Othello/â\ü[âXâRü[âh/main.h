#pragma once
#include "board.h"


class MyWinSock;
MyWinSock* p_winsock = nullptr;

Board* p_board = nullptr;

class Player;
Player* p_player_server = nullptr;
Player* p_player_client = nullptr;

enum Preset :int {
	DEFAULT,
	SERVER_WIN,
	SERVER_DEFEAT,
	SERVER_MULTI_CLOSE,
	CLIENT_MULTI_CLOSE,
	SERVER_COMPLETE,
	CLIENT_COMPLETE,
	SERVER_PASS,
	CLIENT_PASS,
	OUTRANGE,
};

Board::BoardState m_turn = Board::BoardState::SERVER;

bool m_finish = false;
int m_pass_times = 0;

//�v���g�^�C�v�錾
void Init();
void Uninit();
void Update();
void Draw();
void SetPreset(Preset preset);
void Finish(Board::BoardState state);