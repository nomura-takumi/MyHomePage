#pragma once
#include "board.h"

class Player {
private:
	Coord m_coord;
	Board* p_board = nullptr;
	bool InputNumber();
	enum InputResult : int {
		SUCCESS = 0,
		FAILURE,
	};

public:
	Player() {}
	~Player() {
		p_board = nullptr;
	}

	//�ʐM���̃N���C�A���g�̏���
	bool InputNumber(char x, char y);
	Coord ConvertToCoord(char x, char y);

	void Input(Board::BoardState self);
	bool Input(Board::BoardState self, Coord coord);
	void SetBoardInstance(Board* pBoard) {
		p_board = pBoard;
	}
};