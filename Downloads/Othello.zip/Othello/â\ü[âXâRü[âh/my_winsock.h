#pragma once
#include <winSock2.h>


class Player;

class MyWinSock {
private:
	SOCKADDR_IN from;
	int from_len = sizeof(from);
	SOCKET accept_socket;

	SOCKET server_socket;
	char buff[1024];

	typedef int ERROR_CODE;
	ERROR_CODE error_code;

	Player* p_player_client = nullptr;

public:
	MyWinSock();
	~MyWinSock();
	void Update();
	void PrintErrorCode(ERROR_CODE code);

	ERROR_CODE GetErrorCode() {
		return error_code;
	}

	void SetPlayerInstance(Player* p_client) {
		p_player_client = p_client;
	}
};